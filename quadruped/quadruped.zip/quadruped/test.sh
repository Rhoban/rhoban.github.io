

source /tmp/py3/bin/activate
