#!/bin/bash
pip install numpy pygame pybullet onshape-to-robot transforms3d scipy
