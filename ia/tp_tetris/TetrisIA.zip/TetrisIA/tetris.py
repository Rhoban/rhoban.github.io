import argparse
from kernel import *
import value_iteration as vi

##############################################################################

if __name__ == "__main__":
    
    parser = argparse.ArgumentParser(description="Tetris")

    parser.add_argument(
        "--user-game",
        action='store_true',
        help="Interactive gaming",
        default=False
    )

    parser.add_argument(
        "--compute-policy",
        action='store_true',
        help="compute the policy",
        default=False
    )

    parser.add_argument(
        "--eval-policy",
        action='store_true',
        help="Evaluate the policy",
        default=False
    )

    parser.add_argument(
        "--eval-random-policy",
        action='store_true',
        help="Evaluate the random policy",
        default=False
    )

    parser.add_argument(
        "--test-policy",
        action='store_true',
        help="test the policy",
        default=False
    )

    for w,h in params.arena_sizes:
        parser.add_argument(
            "--%dx%d" % (w,h),
            action='store_true',
            help="arena of size %dx%d" % (w,h),
            default=False
        )

    args = parser.parse_args()

    for w,h in params.arena_sizes:
        if getattr(args,str(w)+'x'+str(h)):
            params.width = w
            params.height = h

    if args.user_game:
        Game.user_game()

    if args.compute_policy:
        vi.compute_policy()

    if args.eval_policy:
        vi.eval_policy()

    if args.eval_random_policy:
        vi.eval_policy(policy=vi.random_policy())

    if args.test_policy:
        vi.test_policy()