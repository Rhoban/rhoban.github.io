from kernel import *
import os
import pickle
import util

def compute_transition_matrix():
    print('- computing transition and score matrix ', end='')
    actions = Action.action_list()
    transitions = np.ndarray((Game.state_nb(), len(actions)), dtype=int)
    scores = np.ndarray((Game.state_nb(), len(actions)), dtype=int)
    transitions.fill(-1)
    scores.fill(-1)
    n = 0
    for s0 in range(Game.state_nb()):
        for a in range(len(actions)):
            s1, score = Game.transition(s0,actions[a])
            if s1 is not None: 
                transitions[s0,a] = s1
                scores[s0,a] = score
            n += 1
            if n%10000 == 0: 
                print('.', end='')
                sys.stdout.flush()
    print()
    return transitions, scores

def compute_successors(transitions, s, a):
    succ_s = transitions[s,a]
    if succ_s < 0:
        return []
    succs = []
    for pid in range(Piece.piece_nb()):
        s1 = Game.modify_current_piece_in_idx(succ_s, pid)
        p = Piece.proba(pid)
        succs.append((p,s1))
    return succs

def compute_successor_matrix(transitions):
    print('- computing successors ', end='')
    successors = np.ndarray((Game.state_nb(), Action.action_nb()), dtype=object)
    N=0
    for s in range(Game.state_nb()):
        for a in range(Action.action_nb()):
            successors[s,a] = compute_successors(transitions, s,a)
            if N%10000 == 0:
                print('.', end='')
                sys.stdout.flush()
            N+=1
    print()
    return successors

def compute_reward_matrix(scores):
    print('- computing reward matrix')
    rewards = np.ndarray((Game.state_nb(), Action.action_nb()))
    # A VOUS DE JOUER !!!
    rewards.fill(0)
    return rewards

def compute_value_and_policy(transitions, rewards, successors = None, gamma = 0.90):
    policy = np.ndarray((Game.state_nb()), dtype=int)
    V = np.ndarray((Game.state_nb()), dtype=float)
    # A VOUS DE JOUER !!!
    V.fill(0)
    policy.fill(0)
    return V, policy

def compute_policy():

    transitions_nb = Game.state_nb() * Action.action_nb()
    print('- arena size: (%d,%d)' % (params.width, params.height))
    print('- %d states' % Game.state_nb())
    print('- %d transitions' % transitions_nb)

    transition_file = 'transitions_%d_%d.pickle' % (params.width, params.height)
    transitions, scores = util.cache(lambda: compute_transition_matrix(), transition_file) 
    
    successors = None
    if params.use_successor_matrix:
        successor_file = 'successors_%d_%d.pickle' % (params.width, params.height)
        successors = util.cache(lambda: compute_successor_matrix(transitions), successor_file)

    reward_file = 'rewards_%d_%d.pickle' % (params.width, params.height)
    rewards = util.cache(lambda: compute_reward_matrix(scores), reward_file)

    V_file = 'value_and_policy_%d_%d.pickle' % (params.width, params.height)
    V, policy = util.cache(lambda: compute_value_and_policy(transitions, rewards, successors, gamma = 0.90), V_file)
    return V, policy

def test_policy(V_file = None):

    if V_file is None:
        V_file = params.data_path + '/value_and_policy_%d_%d.pickle' % (params.width, params.height)
    
    if not os.path.exists(V_file):
        print('- unable to find file %s, computing policy:' % V_file)
        V,policy = compute_policy()
    else:
        print('- loading policy file')
        with open(V_file, 'rb') as f:
            V, policy = pickle.load(f)

    while True:
        print('Starting a new game')
        G = Game(simplification=False)
        while G.active:
            N = G.idx_of_game_state()
            print(G)
            a = policy[N]
            if a < 0:
                print('Game over!..')
                print('*'*80)
                input('[press enter (Ctrl+C to quit)]')
                break                
            print('Action: %s' % str(Action.action_of_idx(a)))
            G.play(Action.action_of_idx(a))
            input('[press enter (Ctrl+C to quit)]')

def random_policy():
    print('- computing random policy')
    policy = np.ndarray((Game.state_nb()), dtype=int)
    for n in range(Game.state_nb()):
        policy[n] = random.randint(0, Action.action_nb()-1)
    return policy

def eval_policy(V_file = None, policy = None):
    if policy is None:
        if V_file is None:
            V_file = params.data_path + '/value_and_policy_%d_%d.pickle' % (params.width, params.height)
        
        if not os.path.exists(V_file):
            print('- unable to find file %s (run --compute-policy)' % V_file)
            _, policy = compute_policy()
        else:
            print('- loading policy file')
            with open(V_file, 'rb') as f:
                _, policy = pickle.load(f)
    game_nb = 1000
    print('- testing over %d games' % game_nb)
    scores = []
    for n in range(game_nb):
        G = Game(simplification=False)
        while G.active:
            N = G.idx_of_game_state()
            a = policy[N]
            if a < 0: break                
            if not G.play(Action.action_of_idx(a)): break
        scores.append(G.score)
    print('- score (number of lines):')
    print('  - mean: %0.2f' % np.array(scores).mean())
    print('  - standard deviation: %0.2f' % np.array(scores).std())
    print('  - median: %0.2f' % np.median(np.array(scores)))
    
