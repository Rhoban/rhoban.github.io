import numpy as np
import sys
import copy
import random
import time
import params

# Etat: S = { 6-uplet d'entiers entre 0 et 6 } x { piece }
# Remarque: On fait une (lourde) simplification, on ne considère pas les "trou" dans la
#           construction, mais seulement la ligne d'horizon, avec la hauteur du plus haut
#           trou
# Action: rotation x position laterale : {0, 90, 180, 270} x { 0, 1, ... , width-2}
# Transition: S x A -> S

# TODO: limiter l'action du x, là, ça déclanche une exception.

random.seed(time.time())

class Action:
    def __init__(self, rot, x):
        self.x = x
        self.rot = rot

    def __str__(self):
        if self.rot == 0: r = 'no rotation'
        else: r = '%d deg to left' % self.rot
        return '[ %s | %d units to right ]' % (r, self.x)

    def valid(self):
        return (self.rot in [0, 90, 180, 270] and \
                0 <= self.x and self.x < params.width)

    def idx_of_action(act):
        rot_idx = { 0: 0, 90:1, 180:2, 270:3 }
        return params.width * rot_idx[act.rot] + act.x

    def action_of_idx(aid):
        rid = 0
        while aid >= rid * params.width: rid += 1
        if aid < params.width*rid: rid -= 1
        x = aid - params.width*rid
        return Action(rid*90, x)

    def action_list():
        actions = []
        for r in [ 0, 90, 180, 270 ]:
            for x in range(params.width):
                actions.append(Action(r,x))
        return actions

    def action_nb():
        return 4 * params.width



class Piece:

    # the piece are live in {bloc list} x probability
    pieces = [ [ [[0,0], [0,1], [0,2], [0,3]], 1/7 ],
               [ [[0,0], [0,1], [1,0], [1,1]], 1/7 ],
               [ [[0,0], [0,1], [0,2], [1,2]], 1/7 ],
               [ [[0,0], [1,0], [2,0], [2,1]], 1/7 ],
               [ [[0,0], [1,0], [1,1], [1,2]], 1/7 ],
               [ [[1,0], [1,1], [0,1], [0,2]], 1/7 ],
               [ [[0,0], [0,1], [0,2], [1,1]], 1/7 ] ]

    def piece_nb():
        return len(Piece.pieces)

    def __init__(self, n):
        if n<0 or n>=Piece.piece_nb():
            print('Error: I have only %d pieces' % Piece.piece_nb())
        self.id = n
        self.blocs = copy.deepcopy(Piece.pieces[n][0])

    def translate(self, x, y):
        for b in self.blocs: 
            b[0] = b[0] + x
            b[1] = b[1] + y
 
    def rotate(self, theta_deg):
        if theta_deg == 0: return
        def rot(theta, M):
            x,y = M
            return [int(np.rint(x*np.cos(theta) - y*np.sin(theta))),
                    int(np.rint(x*np.sin(theta) + y*np.cos(theta)))]
        self.blocs = list(map(lambda b: rot(theta_deg/180*np.pi, b), self.blocs))
        min_x = min(list(zip(*self.blocs))[0])
        self.translate(-min_x,0)

    def move(self, theta_deg, x, y):
        self.rotate(theta_deg)
        self.translate(x, y)

    def proba(n):
        return Piece.pieces[n][1]

    def random():
        r = random.random()
        c = 0.0
        for i in range(Piece.piece_nb()):
            c += Piece.proba(i)
            if r < c: return Piece(i)
        return Piece(Piece.piece_nb()-1)

class Game:

    def __init__(self, horizon = None, piece_id = None, simplification=True):
        self.piece_rank = 0
        self.blocs = []
        # simplification means that one consider the height of the higher
        # hole, and one does not delete any line under it
        # this mode is used to compute transitions, but not for playing
        self.simplification = simplification
        self.higher_hole = -1 # this is for the simplification of the state
                              # we keep here the height of the higher hole
        if horizon is not None:
            # here one constructs an approximate state from the horizon only
            # this means that there is no hole under the horizon line
            for x in range(params.width):
                for y in range(horizon[x]):
                    self.blocs.append([[x,y], 0, 0]) 
            self.blocs.sort(key=lambda b: (b[0][1], b[0][0]))
        if piece_id is None:
            self.current_piece = copy.deepcopy(Piece.random())
        else:
            self.current_piece = copy.deepcopy(Piece(piece_id))
        self.horizon = None
        self.score = 0
        self.active = True

    # the horizon is the highest line of the construction
    def get_horizon(self, recompute=False):
        if self.horizon is None or recompute:
            self.horizon = [0]*params.width
            for b,_,_ in self.blocs:
                self.horizon[b[0]] = max(self.horizon[b[0]], b[1]+1)
        return self.horizon

    # one computes the height of the higher hole in the 
    # construction
    def compute_higher_hole(self):
        H = self.get_horizon(recompute=True)
        M = max(H)
        h = self.higher_hole
        done = False
        for x in range(params.width):
            for y in range(h+1, H[x]):
                if y <= h: continue
                found = False
                for b,_,_ in self.blocs:
                    if b[0]==x and b[1]==y: 
                        found = True
                        break
                if not found: h=y
                if h >= M-1: 
                    done = True
                    break
            if done: break
        self.higher_hole = h

    def altitude(self, p):
        H = self.get_horizon()
        alt = np.inf
        for b in p.blocs:
            hb = b[1] - H[b[0]]
            if alt > hb: alt = hb
        return alt

    def add_piece(self,p):
        # ajout des nouveaux blocs
        for b in p.blocs:
            self.blocs.append([b,p.id,self.piece_rank])
        self.piece_rank += 1
        self.blocs.sort(key=lambda b: (b[0][1], b[0][0]))
        self.compute_higher_hole()
        while self.delete_lines(): pass

    def delete_lines(self):
        # detection des lignes pleines
        found_lines = False
        bloc_to_delete = []
        current_line_blocs = []
        curr_x = None
        curr_y = None
        i=0
        while i<len(self.blocs):
            next_line = False
            curr_b = self.blocs[i][0]
            if curr_y is None:
                curr_y = curr_b[1]
                curr_x = 0
                current_line_blocs = []
            if curr_y == curr_b[1]:
                if curr_x == curr_b[0]:
                    current_line_blocs.append(i)
                    curr_x += 1
                    if curr_x == params.width:
                        if (not self.simplification) or (curr_y > self.higher_hole):
                            bloc_to_delete = bloc_to_delete + current_line_blocs
                            self.score += 1
                            found_lines = True
                        next_line = True
                else: next_line = True
            else: next_line = True
            if next_line:
                while i<len(self.blocs):
                    if curr_y != self.blocs[i][0][1]:
                        curr_y = self.blocs[i][0][1]
                        break
                    i += 1
                current_line_blocs = []
                curr_x = 0
            else:
                i += 1
        # suppression des lignes détectées
        bloc_to_delete.reverse()
        for i in bloc_to_delete:
            del self.blocs[i]

        def has_other_bloc_at(x,y, rnk):
            for b,_,rnk1 in self.blocs:
                if rnk1 == rnk: continue 
                if b[0]==x and b[1]==y: return True
            return False

        all_rank = set()
        for _,_,rnk in self.blocs: all_rank.add(rnk)

        for rnk in list(all_rank):
            min_k = np.inf
            for b,_,rnk1 in self.blocs:
                if rnk1 != rnk: continue
                k = 0
                while b[1]-k-1 >= 0 and not has_other_bloc_at(b[0],b[1]-k-1,rnk):
                    k += 1
                if k < min_k: min_k = k
            if min_k > 0:
                for b,_,rnk1 in self.blocs:
                    if rnk1 != rnk: continue
                    b[1] = b[1]-min_k
        
        return found_lines

    # return if action is not valid
    # game over is signaled by self.active
    def play(self, action):
        if not action.valid(): return False
        self.current_piece.move(action.rot, action.x, 10) 
        for b in self.current_piece.blocs:
            if b[0] < 0 or b[0] >= params.width: 
                return False 
        h = self.altitude(self.current_piece)
        if h < 0: return False
        self.current_piece.move(0,0,-h)
        self.add_piece(self.current_piece)
        H = self.get_horizon(recompute=True)
        M = max(H)
        if M > params.height-1: self.active = False
        self.current_piece = Piece.random()
        return True

    def __str__(self):
        screen_width = 20
        screen_height = 10
        screen = np.ndarray((screen_height, screen_width), dtype=int)
        screen.fill(ord(' '))
        for i in range(params.width+1):
            screen[screen_height-1][i] = ord('-')
        for j in range(params.height):
            screen[screen_height-j-1][0] = ord('|')
            screen[screen_height-j-1][params.width+1] = ord('|')
        if self.simplification:
            screen[screen_height-1-(self.higher_hole+1)][params.width+2] = ord('H')

        def draw_piece(plst,x,y):
            for b,id,_ in plst:
                screen[screen_height-1-b[1]-x][y+b[0]] = ord('0') + id
        
        draw_piece(list(zip(self.current_piece.blocs, [self.current_piece.id]*(len(self.current_piece.blocs)), [0]*(len(self.current_piece.blocs)))),2,15)
        draw_piece(self.blocs,1,1)

        s = '-' * 40 + '\n'
        s += 'score: %s\n' % self.score
        s += '-' * 40 + '\n'
        for l in screen:
            for c in l:
                s += chr(c)
            s += '\n'
        return s

    def state_nb():
        return params.height**(params.width+1) * Piece.piece_nb()

    def HPH_to_idx(H,p,h):
        # horizon encoding
        base = params.height
        M = base**(params.width+1) # +1 for the encoding of higher_hole
        P = 1
        N = 0
        for i in range(params.width):
            N += H[i] * P
            P *= base
        N += (h+1)*P
        # current piece encoding
        N = N + p * M
        return N

    def idx_to_HPH(N):
        # decoding piece
        base = params.height
        M = base**(params.width+1) # +1 for the encoding of higher_hole
        id = 0
        while id*M <= N: id += 1
        id -= 1
        # decoding horizon
        H = []
        N -= id*M
        for i in range(params.width):
            H.append(N%base)
            N = N // base
        hh = N%base
        return H,id,hh-1

    def game_state_to_idx(self):
        return Game.HPH_to_idx(self.get_horizon(),self.current_piece.id,self.higher_hole)

    def idx_to_game_state(N):
        H,id,hh = Game.idx_to_HPH(N)
        G = Game(horizon=H, piece_id=id)
        G.higher_hole = hh
        return G
    
    def modify_current_piece_in_idx(s, p):
        Hs, ps, h = Game.idx_to_HPH(s)
        return Game.HPH_to_idx(Hs,p,h)

    def user_game():
        G = Game(horizon=None, piece_id=None, simplification=False)
        try:
            while True:
                print(G)
                order = input('order please ? (rotation in deg to the left and lateral position separated by a space)\n')
                arg = order.split(' ')
                if len(arg) != 2:
                    print('I need rotation (0, 90, 180 or 270) and lateral translation !')
                    continue
                rot, x = int(arg[0]), int(arg[1])
                if not G.play(Action(rot,x)):
                    print('Action not valid')
                    print('Game over')
                    break
                if not G.active:
                    print('Game over')
                    break
        except KeyboardInterrupt:
            print()

    def transition(state_id, action):
        G = Game.idx_to_game_state(state_id)
        if G.play(action):
            if G.active:
                return G.game_state_to_idx(), G.score
        return None, None

