# Arena size
arena_sizes = [(4,4), (5,5), (6,6)]
height = 4
width = 4

use_successor_matrix = False
value_iteration_timout = 60
data_path = 'data'