import os
import pickle
import params

def cache(f, file_name):
    full_file_name = params.data_path + '/' + file_name
    if os.path.exists(full_file_name):
        print('- loading file %s' % full_file_name)
        with open(full_file_name, 'rb') as file:
            return pickle.load(file)
    else:
        result = f()
        with open(full_file_name, 'wb') as file:
            print('- saving in file %s' % full_file_name)
            pickle.dump(result, file)
        return result
